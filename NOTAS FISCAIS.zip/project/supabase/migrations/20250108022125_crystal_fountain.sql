/*
  # Initial Schema Setup for Financial Management System

  1. Tables
    - invoices (Notas Fiscais)
    - daily_allowances (Diárias)
    - bills (Boletos)
    - reimbursements (Reembolsos)
    - users (Usuários do sistema)
    - audit_logs (Logs de auditoria)

  2. Security
    - RLS policies for all tables
    - Role-based access control
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum types
CREATE TYPE document_status AS ENUM ('pending', 'approved', 'rejected', 'cancelled', 'replaced', 'paid', 'overdue');
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'operator');

-- Users table (extends Supabase auth.users)
CREATE TABLE users (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'operator',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Invoices table
CREATE TABLE invoices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_name TEXT NOT NULL,
  document_number TEXT NOT NULL,
  invoice_number TEXT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  issue_date DATE NOT NULL,
  status document_status NOT NULL DEFAULT 'pending',
  pdf_url TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Daily allowances table
CREATE TABLE daily_allowances (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  driver_name TEXT NOT NULL,
  days_count INTEGER NOT NULL,
  daily_rate DECIMAL(10,2) NOT NULL,
  vehicle_plate TEXT NOT NULL,
  issue_date DATE NOT NULL,
  expected_travel_date DATE NOT NULL,
  total_cost DECIMAL(10,2) GENERATED ALWAYS AS (days_count * daily_rate) STORED,
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Bills table
CREATE TABLE bills (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  beneficiary TEXT NOT NULL,
  bill_number TEXT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  due_date DATE NOT NULL,
  issue_date DATE NOT NULL,
  status document_status NOT NULL DEFAULT 'pending',
  pdf_url TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reimbursements table
CREATE TABLE reimbursements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_name TEXT NOT NULL,
  employee_id TEXT NOT NULL,
  reason TEXT NOT NULL CHECK (LENGTH(reason) >= 50),
  requested_amount DECIMAL(10,2) NOT NULL,
  request_date DATE NOT NULL,
  status document_status NOT NULL DEFAULT 'pending',
  attachments TEXT[],
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Audit logs table
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  table_name TEXT NOT NULL,
  record_id UUID NOT NULL,
  action TEXT NOT NULL,
  old_data JSONB,
  new_data JSONB,
  performed_by UUID REFERENCES users(id),
  performed_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_allowances ENABLE ROW LEVEL SECURITY;
ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
ALTER TABLE reimbursements ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
-- Users policies
CREATE POLICY "Users can view their own data"
  ON users
  FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Admins can manage all users"
  ON users
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );

-- Common policies for all document tables
CREATE POLICY "Users can view all documents"
  ON invoices
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only managers and admins can create documents"
  ON invoices
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role IN ('admin', 'manager')
    )
  );

-- Similar policies for other tables
CREATE POLICY "Users can view all documents"
  ON daily_allowances
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view all documents"
  ON bills
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view all documents"
  ON reimbursements
  FOR SELECT
  TO authenticated
  USING (true);

-- Audit log policies
CREATE POLICY "Users can view audit logs"
  ON audit_logs
  FOR SELECT
  TO authenticated
  USING (true);

-- Create indexes
CREATE INDEX idx_invoices_company_name ON invoices(company_name);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_daily_allowances_driver ON daily_allowances(driver_name);
CREATE INDEX idx_bills_beneficiary ON bills(beneficiary);
CREATE INDEX idx_bills_status ON bills(status);
CREATE INDEX idx_reimbursements_employee ON reimbursements(employee_name);
CREATE INDEX idx_reimbursements_status ON reimbursements(status);

-- Create functions for automatic updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_invoices_updated_at
    BEFORE UPDATE ON invoices
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_daily_allowances_updated_at
    BEFORE UPDATE ON daily_allowances
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bills_updated_at
    BEFORE UPDATE ON bills
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_reimbursements_updated_at
    BEFORE UPDATE ON reimbursements
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create audit log trigger function
CREATE OR REPLACE FUNCTION process_audit_log()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO audit_logs (table_name, record_id, action, old_data, performed_by)
        VALUES (TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD), auth.uid());
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_logs (table_name, record_id, action, old_data, new_data, performed_by)
        VALUES (TG_TABLE_NAME, NEW.id, 'UPDATE', row_to_json(OLD), row_to_json(NEW), auth.uid());
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO audit_logs (table_name, record_id, action, new_data, performed_by)
        VALUES (TG_TABLE_NAME, NEW.id, 'INSERT', row_to_json(NEW), auth.uid());
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ language 'plpgsql';