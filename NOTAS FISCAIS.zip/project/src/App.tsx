import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Invoices from './pages/Invoices';
import DailyAllowances from './pages/DailyAllowances';
import Bills from './pages/Bills';
import Reimbursements from './pages/Reimbursements';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import { Toaster } from './components/ui/toaster';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/invoices" element={<Invoices />} />
          <Route path="/daily-allowances" element={<DailyAllowances />} />
          <Route path="/bills" element={<Bills />} />
          <Route path="/reimbursements" element={<Reimbursements />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </Layout>
      <Toaster />
    </Router>
  );
}

export default App;