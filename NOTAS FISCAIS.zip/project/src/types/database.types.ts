export type DocumentStatus = 'pending' | 'approved' | 'rejected' | 'cancelled' | 'replaced' | 'paid' | 'overdue';
export type UserRole = 'admin' | 'manager' | 'operator';

export interface User {
  id: string;
  full_name: string;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export interface Invoice {
  id: string;
  company_name: string;
  document_number: string;
  invoice_number: string;
  total_amount: number;
  issue_date: string;
  status: DocumentStatus;
  pdf_url?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface DailyAllowance {
  id: string;
  driver_name: string;
  days_count: number;
  daily_rate: number;
  vehicle_plate: string;
  issue_date: string;
  expected_travel_date: string;
  total_cost: number;
  notes?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Bill {
  id: string;
  beneficiary: string;
  bill_number: string;
  amount: number;
  due_date: string;
  issue_date: string;
  status: DocumentStatus;
  pdf_url?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Reimbursement {
  id: string;
  employee_name: string;
  employee_id: string;
  reason: string;
  requested_amount: number;
  request_date: string;
  status: DocumentStatus;
  attachments?: string[];
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  table_name: string;
  record_id: string;
  action: string;
  old_data?: any;
  new_data?: any;
  performed_by: string;
  performed_at: string;
}